Placeholder changelog
=====================

This file is a placeholder; a version-specific ``CHANGELOG-vX.Y.rst`` will be generated during releases from fragments
under changelogs/fragments. On release branches once a release has been created, consult the branch's version-specific
file for changes that have occurred in that branch.
