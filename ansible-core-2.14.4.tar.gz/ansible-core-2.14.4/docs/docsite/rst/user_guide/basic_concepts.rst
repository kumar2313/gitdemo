:orphan:

****************
Ansible concepts
****************

This page has moved to :ref:`Getting started with Ansible<basic_concepts>`.
